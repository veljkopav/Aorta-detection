package prikaz;

import funkcionalnost.PrikazivanjeOriginala;
import funkcionalnost.PrikazivanjeAorte;
import funkcionalnost.Dodavanje;
import javax.swing.*;
import java.awt.*;

public class Meni extends JPanel
{
    public Meni()
    {
        BoxLayout box1=new BoxLayout(this, BoxLayout.LINE_AXIS);
        setBorder(BorderFactory.createEmptyBorder(15,15,15,15));

        //dodaje se teksualni opis sta radi dugme
        JLabel lab1=new JLabel("Ovde dodati sliku: ");
        lab1.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        add(lab1);



        //dodaje se dugme za ucitavanje slike
        JButton dugme_za_dodavanje=new JButton("Slika");
        dugme_za_dodavanje.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        dugme_za_dodavanje.addActionListener(new Dodavanje());
        add(dugme_za_dodavanje);

        //dodaje se opis za dugme
        JLabel lab2 = new JLabel("      Prikazati aortu: ");
        lab2.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        add(lab2);


        //dodaje se dugme za prikaz aorte
        JButton dugme_za_prikaz_aorte = new JButton("Aorta");
        dugme_za_prikaz_aorte.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        dugme_za_prikaz_aorte.addActionListener(new PrikazivanjeAorte(/*254*/));
        add(dugme_za_prikaz_aorte);

        //opis
        add(new JLabel("    *Aorta na snimku predstavlja homogeni obojeni beli krug, pozicioniran na centralnom delu snimka "));



        //dodaje se opis za dugme
        JLabel lab3 = new JLabel("     Prikazati originalni snimak: ");
        lab3.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        add(lab3);


        //dodaje se dugme za prikaz originala
        JButton dugme_za_prikaz_originala = new JButton("Original");
        dugme_za_prikaz_originala.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        dugme_za_prikaz_originala.addActionListener(new PrikazivanjeOriginala());
        add(dugme_za_prikaz_originala);

    }
}

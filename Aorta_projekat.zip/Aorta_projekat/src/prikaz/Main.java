package prikaz;

import prikaz.Glavni;

public class Main {
    public static void main(String[] args)

    {
        Glavni glavni = Glavni.getInstance();
    }
}

package prikaz;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Foto extends JPanel
{
    BufferedImage trenutnaSlika, originalnaSlika, slikaAorta;



    public void dodavanjeSlike(File nova) throws Exception
    {
        originalnaSlika=ImageIO.read(nova);
        trenutnaSlika=originalnaSlika;
        repaint();
    }

    public void prikazivanjeOriginala()
    {
        trenutnaSlika=originalnaSlika;
        repaint();
    }

    public BufferedImage pronalazakAorte(BufferedImage originalnaSlika)
    {
        slikaAorta=new BufferedImage(originalnaSlika.getWidth(),originalnaSlika.getHeight(),BufferedImage.TYPE_INT_RGB);

        Color crvena_boja= new Color(255,0,0);
        int crvena=crvena_boja.getRGB();


        // svaki piksel se proverava i ako je bele boje boji se u crveno kako bi aorta bila akcentovana jer je ona bele boje
        for (int i = 0; i < slikaAorta.getWidth(); i++)
            for (int j = 0; j < slikaAorta.getHeight(); j++) {
                int rgb = originalnaSlika.getRGB(i, j);
                int gs = rgb & 0xff;
                if (gs==255)    //threshold je 255
                    slikaAorta.setRGB(i,j,crvena);
                else
                    slikaAorta.setRGB(i,j,originalnaSlika.getRGB(i,j));

            }
        return slikaAorta;
    }

    public void prikazAorte() throws Exception
    {
        slikaAorta = pronalazakAorte(originalnaSlika);
        trenutnaSlika = slikaAorta;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        Dimension d = this.getSize();
        g.drawImage(trenutnaSlika, 0, 0, d.width, d.height, this);
    }



}

package prikaz;

import javax.swing.*;
import java.awt.*;

public class Glavni extends JFrame
{
    private static Glavni instance=null;

    Meni gore;
    Foto dole;

    private Glavni()
    {
        setTitle("Pronalazenje aorte");

        gore=new Meni();
        dole=new Foto();

        JSplitPane split=new JSplitPane(JSplitPane.VERTICAL_SPLIT,gore,dole);
        split.setDividerLocation(75);
        add(split,BorderLayout.AFTER_LINE_ENDS);
        setSize(1250,700);
        setLocationRelativeTo(null);
        setVisible(true);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }

    public Meni getGore()
    {
        return gore;
    }
    public Foto getDole() {return dole;}

    public static Glavni getInstance()
    {
        if(instance==null)
            instance=new Glavni();

        return instance;
    }
}

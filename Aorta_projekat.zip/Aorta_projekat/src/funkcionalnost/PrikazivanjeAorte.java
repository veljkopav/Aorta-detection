package funkcionalnost;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import prikaz.Glavni;
import javax.swing.*;

public class PrikazivanjeAorte implements ActionListener
{
    @Override
    public void actionPerformed(ActionEvent e)
    {
        try
        {
            Glavni.getInstance().getDole().prikazAorte();
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Molimo učitajte sliku","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
}


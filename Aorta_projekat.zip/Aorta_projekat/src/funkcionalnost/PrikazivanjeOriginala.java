package funkcionalnost;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import prikaz.Glavni;

public class PrikazivanjeOriginala implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e)
    {
        Glavni.getInstance().getDole().prikazivanjeOriginala();
    }
}

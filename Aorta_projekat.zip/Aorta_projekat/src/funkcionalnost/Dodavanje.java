package funkcionalnost;

import prikaz.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;

public class Dodavanje implements ActionListener
{

    @Override
    public void actionPerformed(ActionEvent e)
    {
        JFileChooser fch=new JFileChooser();
        int izbor=fch.showOpenDialog(null);

        if(izbor!=JFileChooser.APPROVE_OPTION) return;

        File izabran=fch.getSelectedFile();


        try
        {
            Glavni.getInstance().getDole().dodavanjeSlike(izabran);
        }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null,"Doslo je do greske prilikom unosa slike");
        }
    }

}
